
var ApiGen = ApiGen || {};
ApiGen.elements = [["f","ajouterArticle()"],["c","CAD"],["f","compterArticles()"],["f","creationPanier()"],["f","modifierQTeArticle()"],["f","MontantGlobal()"],["f","supprimePanier()"],["f","supprimerArticle()"],["c","User"]];
